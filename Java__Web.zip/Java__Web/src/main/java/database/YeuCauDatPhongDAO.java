package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.YeuCauDatPhong;
import model.KhachHang;
import model.NhanVien;
import model.Phong;

public class YeuCauDatPhongDAO implements DAOInterface<YeuCauDatPhong> {

    @Override
    public ArrayList<YeuCauDatPhong> selectAll() {
        ArrayList<YeuCauDatPhong> ketQua = new ArrayList<>();
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM yeucau_datphong";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maDatPhong = rs.getString("madatphong");
                String ngayDatPhong = rs.getString("ngaydatphong");
                String trangThai = rs.getString("trangthai");
                
                // Lấy thông tin Khách Hàng
                String maKhachHang = rs.getString("makhachhang");
                KhachHang khachHang = new KhachHangDAO().selectById(new KhachHang(maKhachHang, "", "", "", "", "", ""));
                
                // Lấy thông tin Nhân Viên
                String maNhanVien = rs.getString("manhanvien");
                NhanVien nhanVien = new NhanVienDAO().selectById(new NhanVien(maNhanVien, "", "", "", "", "","", null, ""));
                
                // Lấy thông tin Phòng
                String maPhong = rs.getString("maphong");
                Phong phong = new PhongDAO().selectById(new Phong(maPhong, "", "", 0, 0));
                
                YeuCauDatPhong yeuCauDatPhong = new YeuCauDatPhong(maDatPhong, khachHang, nhanVien, phong, ngayDatPhong, trangThai);
                ketQua.add(yeuCauDatPhong);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public YeuCauDatPhong selectById(YeuCauDatPhong t) {
        YeuCauDatPhong ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM yeucau_datphong WHERE madatphong=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaDatPhong());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maDatPhong = rs.getString("madatphong");
                String ngayDatPhong = rs.getString("ngaydatphong");
                String trangThai = rs.getString("trangthai");
                
                // Lấy thông tin Khách Hàng
                String maKhachHang = rs.getString("makhachhang");
                KhachHang khachHang = new KhachHangDAO().selectById(new KhachHang(maKhachHang, "", "", "", "", "", ""));
                
                // Lấy thông tin Nhân Viên
                String maNhanVien = rs.getString("manhanvien");
                NhanVien nhanVien = new NhanVienDAO().selectById(new NhanVien(maNhanVien, "", "", "", "", "","", null, ""));
                
                
                // Lấy thông tin Phòng
                String maPhong = rs.getString("maphong");
                Phong phong = new PhongDAO().selectById(new Phong(maPhong, "", "", 0, 0));
                
                ketQua = new YeuCauDatPhong(maDatPhong, khachHang, nhanVien, phong, ngayDatPhong, trangThai);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insert(YeuCauDatPhong t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO yeucau_datphong (madatphong, makhachhang, manhanvien, maphong, ngaydatphong, trangthai) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaDatPhong());
            st.setString(2, t.getKhachHang().getMaKhachHang());
            st.setString(3, t.getNhanVien().getMaNhanVien());
            st.setString(4, t.getPhong().getMaPhong());
            st.setString(5, t.getNgayDatPhong());
            st.setString(6, t.getTrangThai());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int update(YeuCauDatPhong t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "UPDATE yeucau_datphong SET makhachhang=?, manhanvien=?, maphong=?, ngaydatphong=?, trangthai=? WHERE madatphong=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getKhachHang().getMaKhachHang());
            st.setString(2, t.getNhanVien().getMaNhanVien());
            st.setString(3, t.getPhong().getMaPhong());
            st.setString(4, t.getNgayDatPhong());
            st.setString(5, t.getTrangThai());
            st.setString(6, t.getMaDatPhong());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int delete(YeuCauDatPhong t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM yeucau_datphong WHERE madatphong=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaDatPhong());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    // Hàm kiểm tra mã yêu cầu đặt phòng đã tồn tại trong cơ sở dữ liệu chưa
    public int sosanh(String maDatPhongMoi) {
        int dem = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM yeucau_datphong WHERE madatphong = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maDatPhongMoi);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                dem = rs.getInt(1); // Lấy số lượng bản ghi trùng mã đặt phòng
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dem;
    }

   

    @Override
    public int deleteAll(ArrayList<YeuCauDatPhong> arr) {
        // TODO Auto-generated method stub
        return 0;
    }
}
