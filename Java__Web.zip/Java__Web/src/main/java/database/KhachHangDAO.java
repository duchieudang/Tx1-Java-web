package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.KhachHang;

public class KhachHangDAO implements DAOInterface<KhachHang> {

    @Override
    public ArrayList<KhachHang> selectAll() {
        ArrayList<KhachHang> ketQua = new ArrayList<>();
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM khachhang";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maKhachHang = rs.getString("makhachhang");
                String tenKhachHang = rs.getString("tenkhachhang");
                String diaChi = rs.getString("diachi");
                String email = rs.getString("email");
                String soDienThoai = rs.getString("sodienthoai");
                String matKhau = rs.getString("matkhau");
                String ngaySinh = rs.getString("ngaysinh");

                KhachHang khachHang = new KhachHang(maKhachHang, tenKhachHang, diaChi, email, soDienThoai, matKhau, ngaySinh);
                ketQua.add(khachHang);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public KhachHang selectById(KhachHang t) {
        KhachHang ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM khachhang WHERE makhachhang=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaKhachHang());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maKhachHang = rs.getString("makhachhang");
                String tenKhachHang = rs.getString("tenkhachhang");
                String diaChi = rs.getString("diachi");
                String email = rs.getString("email");
                String soDienThoai = rs.getString("sodienthoai");
                String matKhau = rs.getString("matkhau");
                String ngaySinh = rs.getString("ngaysinh");

                ketQua = new KhachHang(maKhachHang, tenKhachHang, diaChi, email, soDienThoai, matKhau, ngaySinh);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insert(KhachHang t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO khachhang (makhachhang, tenkhachhang, diachi, email, sodienthoai, matkhau, ngaysinh) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaKhachHang());
            st.setString(2, t.getTenKhachHang());
            st.setString(3, t.getDiaChi());
            st.setString(4, t.getEmail());
            st.setString(5, t.getSoDienThoai());
            st.setString(6, t.getMatKhau());
            st.setString(7, t.getNgaySinh());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int update(KhachHang t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "UPDATE khachhang SET tenkhachhang=?, diachi=?, email=?, sodienthoai=?, matkhau=?, ngaysinh=? WHERE makhachhang=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getTenKhachHang());
            st.setString(2, t.getDiaChi());
            st.setString(3, t.getEmail());
            st.setString(4, t.getSoDienThoai());
            st.setString(5, t.getMatKhau());
            st.setString(6, t.getNgaySinh());
            st.setString(7, t.getMaKhachHang());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int delete(KhachHang t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM khachhang WHERE makhachhang=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaKhachHang());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    // Hàm kiểm tra mã khách hàng đã tồn tại trong cơ sở dữ liệu chưa
    public int sosanh(String maKhachHangMoi) {
        int dem = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM khachhang WHERE makhachhang = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maKhachHangMoi);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                dem = rs.getInt(1); // Lấy số lượng bản ghi trùng mã khách hàng
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dem;
    }

  
    @Override
    public int deleteAll(ArrayList<KhachHang> arr) {
        // TODO Auto-generated method stub
        return 0;
    }
}
