package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Phong;

public class PhongDAO implements DAOInterface<Phong> {

    @Override
    public ArrayList<Phong> selectAll() {
        ArrayList<Phong> ketQua = new ArrayList<>();
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM phong";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maPhong = rs.getString("maphong");
                String tenPhong = rs.getString("tenphong");
                String trangThaiPhong = rs.getString("trangthaiphong");
                double giaPhong = rs.getDouble("giaphong");
                int sucChua = rs.getInt("succhua");

                Phong phong = new Phong(maPhong, tenPhong, trangThaiPhong, giaPhong, sucChua);
                ketQua.add(phong);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public Phong selectById(Phong t) {
        Phong ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM phong WHERE maphong=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaPhong());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maPhong = rs.getString("maphong");
                String tenPhong = rs.getString("tenphong");
                String trangThaiPhong = rs.getString("trangthaiphong");
                double giaPhong = rs.getDouble("giaphong");
                int sucChua = rs.getInt("succhua");

                ketQua = new Phong(maPhong, tenPhong, trangThaiPhong, giaPhong, sucChua);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insert(Phong t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO phong (maphong, tenphong, trangthaiphong, giaphong, succhua) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaPhong());
            st.setString(2, t.getTenPhong());
            st.setString(3, t.getTrangThaiPhong());
            st.setDouble(4, t.getGiaPhong());
            st.setInt(5, t.getSucChua());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int update(Phong t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "UPDATE phong SET tenphong=?, trangthaiphong=?, giaphong=?, succhua=? WHERE maphong=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getTenPhong());
            st.setString(2, t.getTrangThaiPhong());
            st.setDouble(3, t.getGiaPhong());
            st.setInt(4, t.getSucChua());
            st.setString(5, t.getMaPhong());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int delete(Phong t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM phong WHERE maphong=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaPhong());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    // Hàm kiểm tra mã phòng đã tồn tại trong cơ sở dữ liệu chưa
    public int sosanh(String maPhongMoi) {
        int dem = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM phong WHERE maphong = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maPhongMoi);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                dem = rs.getInt(1); // Lấy số lượng bản ghi trùng mã phòng
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dem;
    }

    @Override
    public int deleteAll(ArrayList<Phong> arr) {
        // TODO Auto-generated method stub
        return 0;
    }
}
