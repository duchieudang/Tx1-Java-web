package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.NhanVien;

public class NhanVienDAO implements DAOInterface<NhanVien> {

    @Override
    public ArrayList<NhanVien> selectAll() {
        ArrayList<NhanVien> ketQua = new ArrayList<>();
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM nhanvien";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maNhanVien = rs.getString("manhanvien");
                String tenNhanVien = rs.getString("tennhanvien");
                String diaChi = rs.getString("diachi");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String soCCCD = rs.getString("soccbd");
                String gioiTinh = rs.getString("gioitinh");
                Date ngaySinh = rs.getDate("ngaysinh");
                String matKhau = rs.getString("matkhau");

                NhanVien nhanVien = new NhanVien(maNhanVien, tenNhanVien, diaChi, soDienThoai, email, soCCCD, gioiTinh, ngaySinh, matKhau);
                ketQua.add(nhanVien);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public NhanVien selectById(NhanVien t) {
        NhanVien ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM nhanvien WHERE manhanvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaNhanVien());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maNhanVien = rs.getString("manhanvien");
                String tenNhanVien = rs.getString("tennhanvien");
                String diaChi = rs.getString("diachi");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String soCCCD = rs.getString("soccbd");
                String gioiTinh = rs.getString("gioitinh");
                Date ngaySinh = rs.getDate("ngaysinh");
                String matKhau = rs.getString("matkhau");

                ketQua = new NhanVien(maNhanVien, tenNhanVien, diaChi, soDienThoai, email, soCCCD, gioiTinh, ngaySinh, matKhau);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insert(NhanVien t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO nhanvien (manhanvien, tennhanvien, diachi, sodienthoai, email, soccbd, gioitinh, ngaysinh, matkhau) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaNhanVien());
            st.setString(2, t.getTenNhanVien());
            st.setString(3, t.getDiaChi());
            st.setString(4, t.getSoDienThoai());
            st.setString(5, t.getEmail());
            st.setString(6, t.getSoCCCD());
            st.setString(7, t.getGioiTinh());
            st.setDate(8, new java.sql.Date(t.getNgaySinh().getTime()));
            st.setString(9, t.getMatKhau());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int update(NhanVien t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "UPDATE nhanvien SET tennhanvien=?, diachi=?, sodienthoai=?, email=?, soccbd=?, gioitinh=?, ngaysinh=?, matkhau=? WHERE manhanvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getTenNhanVien());
            st.setString(2, t.getDiaChi());
            st.setString(3, t.getSoDienThoai());
            st.setString(4, t.getEmail());
            st.setString(5, t.getSoCCCD());
            st.setString(6, t.getGioiTinh());
            st.setDate(7, new java.sql.Date(t.getNgaySinh().getTime()));
            st.setString(8, t.getMatKhau());
            st.setString(9, t.getMaNhanVien());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int delete(NhanVien t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM nhanvien WHERE manhanvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaNhanVien());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    // Hàm kiểm tra mã nhân viên đã tồn tại trong cơ sở dữ liệu chưa


    @Override
    public int deleteAll(ArrayList<NhanVien> arr) {
        // TODO Auto-generated method stub
        return 0;
    }

	
}
