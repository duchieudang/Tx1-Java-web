package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.DanhGia;
import model.KhachHang;
import model.Phong;

public class DanhGiaDAO implements DAOInterface<DanhGia> {

    @Override
    public ArrayList<DanhGia> selectAll() {
        ArrayList<DanhGia> ketQua = new ArrayList<>();
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM danhgia";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maDanhGia = rs.getString("madanhgia");
                String maKhachHang = rs.getString("makhachhang");
                String maPhong = rs.getString("maphong");
                int diem = rs.getInt("diem");
                String nhanXet = rs.getString("nhanxet");
                String ngayDanhGia = rs.getString("ngaydanhgia");

                KhachHang khachHang = new KhachHang(); // Assuming KhachHang is already defined
                khachHang.setMaKhachHang(maKhachHang);

                Phong phong = new Phong(); // Assuming Phong is already defined
                phong.setMaPhong(maPhong);

                DanhGia danhGia = new DanhGia(maDanhGia, khachHang, phong, diem, nhanXet, ngayDanhGia);
                ketQua.add(danhGia);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public DanhGia selectById(DanhGia t) {
        DanhGia ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM danhgia WHERE madanhgia=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaDanhGia());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maDanhGia = rs.getString("madanhgia");
                String maKhachHang = rs.getString("makhachhang");
                String maPhong = rs.getString("maphong");
                int diem = rs.getInt("diem");
                String nhanXet = rs.getString("nhanxet");
                String ngayDanhGia = rs.getString("ngaydanhgia");

                KhachHang khachHang = new KhachHang();
                khachHang.setMaKhachHang(maKhachHang);

                Phong phong = new Phong();
                phong.setMaPhong(maPhong);

                ketQua = new DanhGia(maDanhGia, khachHang, phong, diem, nhanXet, ngayDanhGia);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insert(DanhGia t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO danhgia (madanhgia, makhachhang, maphong, diem, nhanxet, ngaydanhgia) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaDanhGia());
            st.setString(2, t.getKhachHang().getMaKhachHang());
            st.setString(3, t.getPhong().getMaPhong());
            st.setInt(4, t.getDiem());
            st.setString(5, t.getNhanXet());
            st.setString(6, t.getNgayDanhGia());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int update(DanhGia t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "UPDATE danhgia SET makhachhang=?, maphong=?, diem=?, nhanxet=?, ngaydanhgia=? WHERE madanhgia=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getKhachHang().getMaKhachHang());
            st.setString(2, t.getPhong().getMaPhong());
            st.setInt(3, t.getDiem());
            st.setString(4, t.getNhanXet());
            st.setString(5, t.getNgayDanhGia());
            st.setString(6, t.getMaDanhGia());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int delete(DanhGia t) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM danhgia WHERE madanhgia=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaDanhGia());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    // Hàm kiểm tra mã đánh giá đã tồn tại trong cơ sở dữ liệu chưa
    public int sosanh(String maDanhGiaMoi) {
        int dem = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM danhgia WHERE madanhgia = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maDanhGiaMoi);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                dem = rs.getInt(1); // Lấy số lượng bản ghi trùng mã đánh giá
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dem;
    }

 

    @Override
    public int deleteAll(ArrayList<DanhGia> arr) {
        // TODO Auto-generated method stub
        return 0;
    }
}
