package model;

public class YeuCauDatPhong {
    private String maDatPhong;
    private KhachHang khachHang;
    private NhanVien nhanVien;
    private Phong Phong;
    private String ngayDatPhong;
    private String trangThai;
	public YeuCauDatPhong(String maDatPhong, KhachHang khachHang, NhanVien nhanVien, model.Phong phong,
			String ngayDatPhong, String trangThai) {
		super();
		this.maDatPhong = maDatPhong;
		this.khachHang = khachHang;
		this.nhanVien = nhanVien;
		Phong = phong;
		this.ngayDatPhong = ngayDatPhong;
		this.trangThai = trangThai;
	}
	public YeuCauDatPhong() {
		super();
	}
	public String getMaDatPhong() {
		return maDatPhong;
	}
	public void setMaDatPhong(String maDatPhong) {
		this.maDatPhong = maDatPhong;
	}
	public KhachHang getKhachHang() {
		return khachHang;
	}
	public void setKhachHang(KhachHang khachHang) {
		this.khachHang = khachHang;
	}
	public NhanVien getNhanVien() {
		return nhanVien;
	}
	public void setNhanVien(NhanVien nhanVien) {
		this.nhanVien = nhanVien;
	}
	public Phong getPhong() {
		return Phong;
	}
	public void setPhong(Phong phong) {
		Phong = phong;
	}
	public String getNgayDatPhong() {
		return ngayDatPhong;
	}
	public void setNgayDatPhong(String ngayDatPhong) {
		this.ngayDatPhong = ngayDatPhong;
	}
	public String getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}

    // Constructor

}
