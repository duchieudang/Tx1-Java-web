package model;

public class DanhGia {
    private String maDanhGia;
    private KhachHang khachHang;
    private Phong Phong;
    private int diem;
    private String nhanXet;
    private String ngayDanhGia;
	
	public DanhGia(String maDanhGia, KhachHang khachHang, model.Phong phong, int diem, String nhanXet,
			String ngayDanhGia) {
		super();
		this.maDanhGia = maDanhGia;
		this.khachHang = khachHang;
		Phong = phong;
		this.diem = diem;
		this.nhanXet = nhanXet;
		this.ngayDanhGia = ngayDanhGia;
	}
	public String getMaDanhGia() {
		return maDanhGia;
	}
	public void setMaDanhGia(String maDanhGia) {
		this.maDanhGia = maDanhGia;
	}
	public KhachHang getKhachHang() {
		return khachHang;
	}
	public void setKhachHang(KhachHang khachHang) {
		this.khachHang = khachHang;
	}
	public Phong getPhong() {
		return Phong;
	}
	public void setPhong(Phong phong) {
		Phong = phong;
	}
	public int getDiem() {
		return diem;
	}
	public void setDiem(int diem) {
		this.diem = diem;
	}
	public String getNhanXet() {
		return nhanXet;
	}
	public void setNhanXet(String nhanXet) {
		this.nhanXet = nhanXet;
	}
	public String getNgayDanhGia() {
		return ngayDanhGia;
	}
	public void setNgayDanhGia(String ngayDanhGia) {
		this.ngayDanhGia = ngayDanhGia;
	}
	public DanhGia() {
		super();
	}

  
}
