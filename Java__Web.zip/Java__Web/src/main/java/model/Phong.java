package model;

public class Phong {
	  private String maPhong;
	    private String tenPhong;
	    private String trangThaiPhong;
	    private double giaPhong;
	    private int sucChua;
		public Phong(String maPhong, String tenPhong, String trangThaiPhong, double giaPhong, int sucChua) {
			super();
			this.maPhong = maPhong;
			this.tenPhong = tenPhong;
			this.trangThaiPhong = trangThaiPhong;
			this.giaPhong = giaPhong;
			this.sucChua = sucChua;
		}
		public Phong() {
			super();
		}
		public String getMaPhong() {
			return maPhong;
		}
		public void setMaPhong(String maPhong) {
			this.maPhong = maPhong;
		}
		public String getTenPhong() {
			return tenPhong;
		}
		public void setTenPhong(String tenPhong) {
			this.tenPhong = tenPhong;
		}
		public String getTrangThaiPhong() {
			return trangThaiPhong;
		}
		public void setTrangThaiPhong(String trangThaiPhong) {
			this.trangThaiPhong = trangThaiPhong;
		}
		public double getGiaPhong() {
			return giaPhong;
		}
		public void setGiaPhong(double giaPhong) {
			this.giaPhong = giaPhong;
		}
		public int getSucChua() {
			return sucChua;
		}
		public void setSucChua(int sucChua) {
			this.sucChua = sucChua;
		}
			    
}
